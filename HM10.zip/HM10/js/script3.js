//3.
// for (let i = 1; i <= 100; i++){
//     if(i % 2 == 0){
//     console.log(i);
//         }
// }

for (let i = 2; i <= 100; i += 2){
    

  
     if((i-1) % 2 == 0){
    console.log(i-1);
        } else if ((i % 2) == 0) {
           console.log(i); 
        }
}
