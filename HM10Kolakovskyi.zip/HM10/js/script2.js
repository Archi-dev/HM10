// 2.

for (let i = 100; i >= 1; i--){
    console.log(i);
}